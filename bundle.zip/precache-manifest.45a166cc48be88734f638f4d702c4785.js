self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "23434d8ba270ffaba4fd7eee2452b8d5",
    "url": "./index.html"
  },
  {
    "revision": "c96fef07a3de8f808aab",
    "url": "./static/css/2.d4488d67.chunk.css"
  },
  {
    "revision": "d38f4be3ba59863386a7",
    "url": "./static/css/main.2253b9bf.chunk.css"
  },
  {
    "revision": "c96fef07a3de8f808aab",
    "url": "./static/js/2.d568a2fb.chunk.js"
  },
  {
    "revision": "d38f4be3ba59863386a7",
    "url": "./static/js/main.389ab8e8.chunk.js"
  },
  {
    "revision": "1b437403f16bd71edadb",
    "url": "./static/js/runtime-main.9d7e574d.js"
  },
  {
    "revision": "c91fff83336af5897d91fb4179cc5eff",
    "url": "./static/media/Alice-Regular.c91fff83.ttf"
  },
  {
    "revision": "9a7e6112b6720174a5bcaf41ce87ca37",
    "url": "./static/media/Daikon-SemiBold.9a7e6112.ttf"
  },
  {
    "revision": "9dbbd6b9979407a9979f18d45592b520",
    "url": "./static/media/FontsFree-Net-SF-Pro-Rounded-Black.9dbbd6b9.ttf"
  },
  {
    "revision": "e64fc9d01f0600a9faf13ce71c15d0ed",
    "url": "./static/media/FontsFree-Net-SF-Pro-Rounded-Bold.e64fc9d0.ttf"
  },
  {
    "revision": "907212050e2a59fbb0aa4cb95b7ca4c0",
    "url": "./static/media/FontsFree-Net-SF-Pro-Rounded-Semibold.90721205.ttf"
  },
  {
    "revision": "3cf0ee273a0b3f022234b6572c3b78f9",
    "url": "./static/media/Gilroy-Bold.3cf0ee27.ttf"
  },
  {
    "revision": "6444f14adcdee041b62184f13139a56d",
    "url": "./static/media/Gilroy-Medium.6444f14a.ttf"
  },
  {
    "revision": "ae5e7255973ffe09b53f07a2805232a8",
    "url": "./static/media/Gilroy-Regular.ae5e7255.ttf"
  },
  {
    "revision": "05bdf30b8aaa10683c19e73dd0c428da",
    "url": "./static/media/Gilroy-SemiBold.05bdf30b.ttf"
  },
  {
    "revision": "de56e6a465e9d9b2ab97c4223ac07b43",
    "url": "./static/media/Icon38Message.de56e6a4.svg"
  },
  {
    "revision": "97decd2b78e0890e270894d96efe328f",
    "url": "./static/media/Inter-Bold.97decd2b.ttf"
  },
  {
    "revision": "5ff1f2a9a78730d7d0c309320ff3c9c7",
    "url": "./static/media/Inter-Medium.5ff1f2a9.ttf"
  },
  {
    "revision": "515cae74eee4925d56e6ac70c25fc0f6",
    "url": "./static/media/Inter-Regular.515cae74.ttf"
  },
  {
    "revision": "ec60b23f3405050f546f4765a9e90fec",
    "url": "./static/media/Inter-SemiBold.ec60b23f.ttf"
  },
  {
    "revision": "1567b63e057e19447a07a5a63fa56d67",
    "url": "./static/media/MainPlaceholderButton.1567b63e.svg"
  },
  {
    "revision": "25fce6f41d5cc8978652646dfd03d378",
    "url": "./static/media/MainPlaceholderButtonLoading.25fce6f4.svg"
  },
  {
    "revision": "d22543958135ad048246739b39369334",
    "url": "./static/media/MainPlaceholderIcon.d2254395.svg"
  },
  {
    "revision": "850ffaa2af959cbc68e9f8ab6ccbf4db",
    "url": "./static/media/Manrope-Bold.850ffaa2.ttf"
  },
  {
    "revision": "6b0f2123870ccd0cfbb6edd650ff6f22",
    "url": "./static/media/Manrope-ExtraBold.6b0f2123.ttf"
  },
  {
    "revision": "f661a8056d8cbfa46500658db3ccb646",
    "url": "./static/media/Manrope-Medium.f661a805.ttf"
  },
  {
    "revision": "f85bb1cdeaa7c5fbbf3ac8dd263149c3",
    "url": "./static/media/Manrope-SemiBold.f85bb1cd.ttf"
  },
  {
    "revision": "2640802b08e8f37e557305e1c116ccd4",
    "url": "./static/media/Manrope.2640802b.ttf"
  },
  {
    "revision": "ee6539921d713482b8ccd4d0d23961bb",
    "url": "./static/media/Montserrat-Regular.ee653992.ttf"
  },
  {
    "revision": "c641dbee1d75892e4d88bdc31560c91b",
    "url": "./static/media/Montserrat-SemiBold.c641dbee.ttf"
  },
  {
    "revision": "2b93e8e975cd6d488fe0e635541728f9",
    "url": "./static/media/ProximaNova-Bold.2b93e8e9.ttf"
  },
  {
    "revision": "1fc524a22c99e8d63393ecfe238e3d35",
    "url": "./static/media/ProximaNova-Regular.1fc524a2.ttf"
  },
  {
    "revision": "3625e925425cb102cadb2f5db79c9aa0",
    "url": "./static/media/ProximaNova-Semibold.3625e925.ttf"
  },
  {
    "revision": "11eabca2251325cfc5589c9c6fb57b46",
    "url": "./static/media/Roboto-Regular.11eabca2.ttf"
  },
  {
    "revision": "644563f48ab5fe8e9082b64b2729b068",
    "url": "./static/media/SF-Pro-Display-Bold.644563f4.otf"
  },
  {
    "revision": "a545fc03ce079844a5ff898a25fe589b",
    "url": "./static/media/SF-Pro-Display-Heavy.a545fc03.otf"
  },
  {
    "revision": "51fd7406327f2b1dbc8e708e6a9da9a5",
    "url": "./static/media/SF-Pro-Display-Medium.51fd7406.otf"
  },
  {
    "revision": "aaeac71d99a345145a126a8c9dd2615f",
    "url": "./static/media/SF-Pro-Display-Regular.aaeac71d.otf"
  },
  {
    "revision": "e6ef4ea3cf5b1b533a85a5591534e3e4",
    "url": "./static/media/SF-Pro-Display-Semibold.e6ef4ea3.otf"
  },
  {
    "revision": "400bd9f855cefe6a13b02eb55a31d511",
    "url": "./static/media/SF-Pro-Rounded-Regular.400bd9f8.ttf"
  },
  {
    "revision": "5b6c7cdfe0acd0fcc93cef7984a08740",
    "url": "./static/media/SF-Pro-Text-Bold.5b6c7cdf.otf"
  },
  {
    "revision": "d7829d9b3a4514b125d758dcace0613b",
    "url": "./static/media/SF-Pro-Text-Heavy.d7829d9b.otf"
  },
  {
    "revision": "9491854a8b6ec3a0c915668083f18fde",
    "url": "./static/media/SF-Pro-Text-Medium.9491854a.otf"
  },
  {
    "revision": "85bd46c1cff02c1d8360cc714b8298fa",
    "url": "./static/media/SF-Pro-Text-Regular.85bd46c1.ttf"
  },
  {
    "revision": "8f079b59ff6659b39b41bc2255c968b8",
    "url": "./static/media/SF-Pro-Text-Semibold.8f079b59.otf"
  },
  {
    "revision": "d4550c5e326a628ac8ef82e9f2703484",
    "url": "./static/media/SFUIDisplay-Regular.d4550c5e.otf"
  },
  {
    "revision": "888e0f3f1d925d57beaf9cc4a7b80dbc",
    "url": "./static/media/SFUIText-Regular.888e0f3f.otf"
  },
  {
    "revision": "c7c4799ed1182d24a48397cf98074b7f",
    "url": "./static/media/Stupid-Head.c7c4799e.ttf"
  },
  {
    "revision": "03428f670a1439505c4e1bce5a0b2d18",
    "url": "./static/media/TTCommons-Bold.03428f67.ttf"
  },
  {
    "revision": "2e6a293a70716ab24d1af2f7de14b226",
    "url": "./static/media/TTCommons-DemiBold.2e6a293a.ttf"
  },
  {
    "revision": "fc6fbc1addf37a7f957715e41b20291d",
    "url": "./static/media/TTCommons-Regular.fc6fbc1a.ttf"
  },
  {
    "revision": "44097099334ab7be3261ff85409a62fc",
    "url": "./static/media/TTFirsNeue-DemiBold.44097099.ttf"
  },
  {
    "revision": "df13f74fd7ca2b2797d475e6a4c66cc2",
    "url": "./static/media/TTFirsNeue-Medium.df13f74f.ttf"
  },
  {
    "revision": "0de1b0e6c40db0a73c06348a08ea2b4f",
    "url": "./static/media/TTFirsNeue-Regular.0de1b0e6.ttf"
  },
  {
    "revision": "d9521fb6878e132c215281e9494e232a",
    "url": "./static/media/WC-Mano-Negra-Bta.d9521fb6.otf"
  }
]);